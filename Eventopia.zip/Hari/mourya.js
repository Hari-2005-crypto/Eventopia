document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('event-form');
    form.addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent form submission
      
      // Display registration message
      alert('Registration done');
    });
  });  